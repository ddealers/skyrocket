/*

NEW ODA
*/


(function() {
  var U4A4,
    __hasProp = {}.hasOwnProperty,
    __extends = function(child, parent) { for (var key in parent) { if (__hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; };

  U4A4 = (function(_super) {
    __extends(U4A4, _super);

    function U4A4() {
      var _this = this;
      this.manifest = [
        {
          id: 'c2',
          src: 'circulo2.png'
        }, {
          id: 'c1',
          src: 'cirulo1.png'
        }, {
          id: 'course',
          src: 'course.png'
        }, {
          id: 'continue',
          src: 'continue_story.png'
        }, {
          id: 'dance',
          src: 'dance.png'
        }, {
          id: 'false',
          src: 'false.png'
        }, {
          id: 'true',
          src: 'true.png'
        }, {
          id: 'header',
          src: 'header.png'
        }, {
          id: 'musical',
          src: 'musical.png'
        }, {
          id: 'nature',
          src: 'nature.png'
        }, {
          id: 'image',
          src: 'image.png'
        }, {
          id: 'pantalla01',
          src: 'pantalla-01.png'
        }, {
          id: 's/silence',
          src: 'silence.mp3'
        }
      ];
      this.onClick = function(dispatcher, target) {
        var d, t;
        d = lib[dispatcher];
        t = lib[target];
        t.complete = true;
        if (d.index === t.success) {
          return lib.scene.success();
        } else {
          return lib.scene.fail();
        }
      };
      this["continue"] = function(dispatcher) {
        var d;
        d = lib[dispatcher];
        return lib.scene.nextStep();
      };
      this.game = {
        header: 'header',
        instructions: {
          x: 110,
          y: 140,
          states: [
            {
              text: ['Read the text. Then answer the questions, click on', '#ital', 'or', '#ital'],
              italics: ['True', 'False.'],
              sound: 's/silence',
              played: false,
              custom: true
            }
          ]
        },
        score: {
          type: 'points',
          x: 20,
          y: 500,
          init: 0,
          total: 15,
          aimg: 'c1',
          acolor: '#333',
          bimg: 'c2',
          bcolor: '#333'
        },
        scenes: [
          {
            answers: {
              collection: [
                [
                  {
                    name: 'lbl1',
                    opts: {
                      text: 'You can take these courses all year.',
                      success: false
                    }
                  }
                ], [
                  {
                    name: 'lbl1',
                    opts: {
                      text: 'Children like to learn in different ways.',
                      success: true
                    }
                  }
                ], [
                  {
                    name: 'lbl1',
                    opts: {
                      text: 'Experts say there are 3 different ways to learn.',
                      success: false
                    }
                  }
                ], [
                  {
                    name: 'btnContinue',
                    opts: {
                      visible: true
                    }
                  }
                ]
              ],
              type: 'steps'
            },
            containers: [
              {
                type: 'img',
                id: 'image',
                x: 420,
                y: 195
              }, {
                type: 'txt',
                id: 't1',
                text: 'Come to our special summer sourses in July and August! We know that children like to learn in different ways. We help you develop the talents you already have. Do you like to draw, sing, dance or hike? We have the perfect course for you! Experts say that there are eight different ways of learning, and we have classes for all of them. Here we present four of our most popular summer workshops.',
                x: 70,
                y: 260,
                lineWidth: 330,
                font: '14px Dosis',
                lineHeight: 25,
                align: 'left'
              }, {
                type: 'btn',
                id: 'btnTrue',
                x: 340,
                y: 555,
                index: true,
                target: 'lbl1',
                "eval": this.onClick,
                states: [
                  {
                    img: {
                      name: 'true',
                      x: 0,
                      y: 0,
                      align: 'mc'
                    }
                  }
                ]
              }, {
                type: 'btn',
                id: 'btnFalse',
                x: 460,
                y: 555,
                index: false,
                target: 'lbl1',
                "eval": this.onClick,
                states: [
                  {
                    img: {
                      name: 'false',
                      x: 0,
                      y: 0,
                      align: 'mc'
                    }
                  }
                ]
              }, {
                type: 'btn',
                id: 'btnContinue',
                x: 700,
                y: 555,
                index: 'next',
                target: 'global',
                visible: false,
                "eval": this["continue"],
                states: [
                  {
                    img: {
                      name: 'continue',
                      x: 0,
                      y: 0,
                      align: 'mc'
                    }
                  }
                ]
              }, {
                type: 'lbl',
                id: 'lbl1',
                x: 400,
                y: 490,
                font: 'Bold 20px Quicksand',
                lineWidth: 600,
                color: '#333',
                align: 'center'
              }
            ],
            groups: []
          }, {
            answers: {
              collection: [
                [
                  {
                    name: 'lbl2',
                    opts: {
                      text: 'If you learn by moving your body, you should take a music class.',
                      success: true
                    }
                  }
                ], [
                  {
                    name: 'lbl2',
                    opts: {
                      text: 'If you take dance class, you should wear comfortable clothes.',
                      success: true
                    }
                  }
                ], [
                  {
                    name: 'lbl2',
                    opts: {
                      text: 'Dance class is on Tuesday and Wednesday afternoons.',
                      success: false
                    }
                  }
                ], [
                  {
                    name: 'btnContinue2',
                    opts: {
                      visible: true
                    }
                  }
                ]
              ],
              type: 'steps'
            },
            containers: [
              {
                type: 'img',
                id: 'dance',
                name: 'dance',
                x: 420,
                y: 210
              }, {
                type: 'txt',
                id: 't2',
                text: 'Do you learn by moving your body? Come to our dance class on Monday, Wednesday and Friday mornings from 3 to 6 p.m. Please wear comfortable clothes and wash your feet before class!',
                x: 70,
                y: 260,
                lineWidth: 330,
                font: '14px Dosis',
                lineHeight: 25,
                align: 'left'
              }, {
                type: 'btn',
                id: 'btnTrue2',
                x: 340,
                y: 555,
                index: true,
                target: 'lbl2',
                "eval": this.onClick,
                states: [
                  {
                    img: {
                      name: 'true',
                      x: 0,
                      y: 0,
                      align: 'mc'
                    }
                  }
                ]
              }, {
                type: 'btn',
                id: 'btnFalse2',
                x: 460,
                y: 555,
                index: false,
                target: 'lbl2',
                "eval": this.onClick,
                states: [
                  {
                    img: {
                      name: 'false',
                      x: 0,
                      y: 0,
                      align: 'mc'
                    }
                  }
                ]
              }, {
                type: 'btn',
                id: 'btnContinue2',
                x: 700,
                y: 555,
                index: 'next',
                target: 'global',
                visible: false,
                "eval": this["continue"],
                states: [
                  {
                    img: {
                      name: 'continue',
                      x: 0,
                      y: 0,
                      align: 'mc'
                    }
                  }
                ]
              }, {
                type: 'lbl',
                id: 'lbl2',
                x: 400,
                y: 480,
                font: 'Bold 20px Quicksand',
                lineWidth: 600,
                color: '#333',
                align: 'center'
              }
            ],
            groups: []
          }, {
            answers: {
              collection: [
                [
                  {
                    name: 'lbl3',
                    opts: {
                      text: 'If you like nature and being outside, you should go to the Wilderness Club.',
                      success: true
                    }
                  }
                ], [
                  {
                    name: 'lbl3',
                    opts: {
                      text: 'On the Wilderness Club you go running, swimming and cooking.',
                      success: false
                    }
                  }
                ], [
                  {
                    name: 'lbl3',
                    opts: {
                      text: 'You need to bring a notebook and a pencil.',
                      success: false
                    }
                  }
                ], [
                  {
                    name: 'btnContinue3',
                    opts: {
                      visible: true
                    }
                  }
                ]
              ],
              type: 'steps'
            },
            containers: [
              {
                type: 'img',
                id: 'nature',
                name: 'nature',
                x: 420,
                y: 210
              }, {
                type: 'txt',
                id: 't3',
                text: 'If you learn by being in nature, come to our Wilderness Club every Saturday and Sunday from 9 a.m to 2 p.m. We hike in the woods and swim in the lake. Learn about plants, trees and animals. Bring your swimsuit, a towel, sunscreen and a big bottle of water.',
                x: 70,
                y: 260,
                lineWidth: 330,
                font: '14px Dosis',
                lineHeight: 25,
                align: 'left'
              }, {
                type: 'btn',
                id: 'btnTrue3',
                x: 340,
                y: 555,
                index: true,
                target: 'lbl3',
                "eval": this.onClick,
                states: [
                  {
                    img: {
                      name: 'true',
                      x: 0,
                      y: 0,
                      align: 'mc'
                    }
                  }
                ]
              }, {
                type: 'btn',
                id: 'btnFalse3',
                x: 460,
                y: 555,
                index: false,
                target: 'lbl3',
                "eval": this.onClick,
                states: [
                  {
                    img: {
                      name: 'false',
                      x: 0,
                      y: 0,
                      align: 'mc'
                    }
                  }
                ]
              }, {
                type: 'btn',
                id: 'btnContinue3',
                x: 700,
                y: 555,
                index: 'next',
                target: 'global',
                visible: false,
                "eval": this["continue"],
                states: [
                  {
                    img: {
                      name: 'continue',
                      x: 0,
                      y: 0,
                      align: 'mc'
                    }
                  }
                ]
              }, {
                type: 'lbl',
                id: 'lbl3',
                x: 400,
                y: 480,
                font: 'Bold 20px Quicksand',
                lineWidth: 600,
                color: '#333',
                align: 'center'
              }
            ],
            groups: []
          }, {
            answers: {
              collection: [
                [
                  {
                    name: 'lbl4',
                    opts: {
                      text: 'You can sing about math.',
                      success: true
                    }
                  }
                ], [
                  {
                    name: 'lbl4',
                    opts: {
                      text: 'The summer musical, Math Rocks, is boring. It feels like class.',
                      success: false
                    }
                  }
                ], [
                  {
                    name: 'lbl4',
                    opts: {
                      text: 'You don\'t have to be a good singer to go. Everybody is welcome.',
                      success: true
                    }
                  }
                ], [
                  {
                    name: 'btnContinue4',
                    opts: {
                      visible: true
                    }
                  }
                ]
              ],
              type: 'steps'
            },
            containers: [
              {
                type: 'img',
                id: 'musical',
                name: 'musical',
                x: 420,
                y: 210
              }, {
                type: 'txt',
                id: 't4',
                text: 'Do you love to learn through music? Come and take part in our Math Rocks musical. Learn songs about arithmetic and fractions! You’ll have so much fun that it won’t feel like class. Come and visit the music department on Wednesdays at 4 p.m. and audition for a part. Everybody is welcome!',
                x: 70,
                y: 260,
                lineWidth: 330,
                font: '14px Dosis',
                lineHeight: 25,
                align: 'left'
              }, {
                type: 'btn',
                id: 'btnTrue4',
                x: 340,
                y: 555,
                index: true,
                target: 'lbl4',
                "eval": this.onClick,
                states: [
                  {
                    img: {
                      name: 'true',
                      x: 0,
                      y: 0,
                      align: 'mc'
                    }
                  }
                ]
              }, {
                type: 'btn',
                id: 'btnFalse4',
                x: 460,
                y: 555,
                index: false,
                target: 'lbl4',
                "eval": this.onClick,
                states: [
                  {
                    img: {
                      name: 'false',
                      x: 0,
                      y: 0,
                      align: 'mc'
                    }
                  }
                ]
              }, {
                type: 'btn',
                id: 'btnContinue4',
                x: 700,
                y: 555,
                index: 'next',
                target: 'global',
                visible: false,
                "eval": this["continue"],
                states: [
                  {
                    img: {
                      name: 'continue',
                      x: 0,
                      y: 0,
                      align: 'mc'
                    }
                  }
                ]
              }, {
                type: 'lbl',
                id: 'lbl4',
                x: 400,
                y: 480,
                font: 'Bold 20px Quicksand',
                lineWidth: 600,
                color: '#333',
                align: 'center'
              }
            ],
            groups: []
          }, {
            answers: {
              collection: [
                [
                  {
                    name: 'lbl5',
                    opts: {
                      text: 'Reading techniques class is for people who can\'t read.',
                      success: false
                    }
                  }
                ], [
                  {
                    name: 'lbl5',
                    opts: {
                      text: 'Speed reading is reading fast. It\'s a reading technique.',
                      success: true
                    }
                  }
                ], [
                  {
                    name: 'lbl5',
                    opts: {
                      text: 'Many stories you read are boring.',
                      success: false
                    }
                  }
                ]
              ],
              type: 'steps'
            },
            containers: [
              {
                type: 'img',
                id: 'course',
                name: 'course',
                x: 420,
                y: 210
              }, {
                type: 'txt',
                id: 't5',
                text: 'If reading makes you happy, come to our reading techniques class. Learn how to speed-read and make word maps. When you speed-read, you read faster and understand the text well. We have great stories for you to read!',
                x: 70,
                y: 260,
                lineWidth: 330,
                font: '14px Dosis',
                lineHeight: 25,
                align: 'left'
              }, {
                type: 'btn',
                id: 'btnTrue5',
                x: 340,
                y: 555,
                index: true,
                target: 'lbl5',
                "eval": this.onClick,
                states: [
                  {
                    img: {
                      name: 'true',
                      x: 0,
                      y: 0,
                      align: 'mc'
                    }
                  }
                ]
              }, {
                type: 'btn',
                id: 'btnFalse5',
                x: 460,
                y: 555,
                index: false,
                target: 'lbl5',
                "eval": this.onClick,
                states: [
                  {
                    img: {
                      name: 'false',
                      x: 0,
                      y: 0,
                      align: 'mc'
                    }
                  }
                ]
              }, {
                type: 'lbl',
                id: 'lbl5',
                x: 400,
                y: 490,
                font: 'Bold 20px Quicksand',
                lineWidth: 600,
                color: '#333',
                align: 'center'
              }
            ],
            groups: []
          }
        ]
      };
      U4A4.__super__.constructor.call(this);
    }

    window.U4A4 = U4A4;

    return U4A4;

  })(Oda);

}).call(this);
